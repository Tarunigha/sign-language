# Sign Language > 2024-12-16 12:18pm
https://universe.roboflow.com/tarunigha-r-g/sign-language-rnu98

Provided by a Roboflow user
License: CC BY 4.0

